package LevelEditor;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * Cette classe repr�sente la carte de jeu sous forme d'un tableau � deux dimensions de int (0 = fond, 1 = bloc ).
 * @author MartinVandersteen
 *
 */

public class level {
	private int lvl[][];
	DataInputStream dis;
	
	public level() {				//On lit ce qu'il est �crit dans le fichier level.txt
		lvl = new int[20][15];
		try {
			dis = new DataInputStream(
			        new BufferedInputStream(
			                 new FileInputStream(
			                   new File("level.txt"))));
			for(int i = 0;i<20;i++){
		    	  for(int j = 0;j<15;j++){
		    		  lvl[i][j] = dis.readInt();
		    	  }
		      }
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("File not found level.txt, fichier cr��.");		//Si on ne trouve pas le fichier on le cr�e
			new FileInit();
		} catch (EOFException e) {
			new FileInit();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}
	
	public int[][] getLvl(){								//Renvoie la map sous forme de tableau
		return this.lvl;
	}
	
	public void inverserLvl(int x, int y){			//Inverse une case en fonction de ses coordonn�es dans le tableau (coordonn�es graphiques /34 )
		if(this.lvl[x][y]==0) this.lvl[x][y] = 1;
		else this.lvl[x][y] = 0;
	}
}
